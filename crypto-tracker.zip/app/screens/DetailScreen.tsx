import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Dimensions
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { useCryptoStore } from '@/store/cryptoStore';
import { fetchChartData, getTimeAgo, formatChange } from '@/services/cryptoAPI';
import { ScreenContainer } from '@/components/screen-container';

const screenWidth = Dimensions.get('window').width;

export default function DetailScreen({ route, navigation }: any) {
  const { cryptoId } = route.params;
  const { selectedCrypto, isLoading, error, fetchCryptoDetail, clearError } = useCryptoStore();
  const [chartData, setChartData] = useState<any>(null);
  const [chartLoading, setChartLoading] = useState(false);

  useEffect(() => {
    // Fetch detailed data
    fetchCryptoDetail(cryptoId);
  }, [cryptoId]);

  useEffect(() => {
    // Fetch chart data
    const loadChartData = async () => {
      setChartLoading(true);
      try {
        const data = await fetchChartData(cryptoId, 7);
        if (data && data.prices) {
          // Process chart data
          const prices = data.prices.map((p: [number, number]) => p[1]);
          const labels = data.prices.map((p: [number, number], index: number) => {
            if (index % 2 === 0) {
              const date = new Date(p[0]);
              return `${date.getMonth() + 1}/${date.getDate()}`;
            }
            return '';
          });

          setChartData({
            labels,
            datasets: [
              {
                data: prices,
                strokeWidth: 2,
                color: (opacity = 1) => `rgba(0, 212, 255, ${opacity})`
              }
            ]
          });
        }
      } catch (err) {
        console.error('Error loading chart:', err);
      } finally {
        setChartLoading(false);
      }
    };

    loadChartData();
  }, [cryptoId]);

  useEffect(() => {
    if (error) {
      Alert.alert('Error', error, [{ text: 'OK', onPress: clearError }]);
    }
  }, [error]);

  if (isLoading && !selectedCrypto) {
    return (
      <ScreenContainer className="bg-[#0A0A0A]">
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color="#00D4FF" />
          <Text style={{ color: '#A0A0A0', marginTop: 12, fontSize: 14 }}>
            Loading details...
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  if (!selectedCrypto) {
    return (
      <ScreenContainer className="bg-[#0A0A0A]">
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <Text style={{ color: '#A0A0A0', fontSize: 16 }}>
            No data available
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  const isPositive = selectedCrypto.change24h >= 0;
  const changeColor = isPositive ? '#00C853' : '#FF3B30';
  const isLive = Date.now() - selectedCrypto.lastUpdated < 30000;

  return (
    <ScreenContainer className="bg-[#0A0A0A]">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header with Back Button */}
        <View style={{ paddingHorizontal: 24, paddingVertical: 16, flexDirection: 'row', alignItems: 'center' }}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{ marginRight: 12 }}
          >
            <Text style={{ color: '#00D4FF', fontSize: 16, fontWeight: '600' }}>
              ← Back
            </Text>
          </TouchableOpacity>
        </View>

        {/* Crypto Info */}
        <View style={{ paddingHorizontal: 24, marginBottom: 24 }}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
            <View>
              <Text style={{ color: '#FFFFFF', fontSize: 28, fontWeight: 'bold', marginBottom: 4 }}>
                {selectedCrypto.name}
              </Text>
              <Text style={{ color: '#A0A0A0', fontSize: 16 }}>
                {selectedCrypto.symbol}
              </Text>
            </View>
            <View style={{ alignItems: 'flex-end' }}>
              {isLive && (
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 8 }}>
                  <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: '#00C853', marginRight: 6 }} />
                  <Text style={{ color: '#00C853', fontSize: 12, fontWeight: '600' }}>
                    Live
                  </Text>
                </View>
              )}
            </View>
          </View>

          {/* Price and Change */}
          <View style={{ backgroundColor: '#1A1A1A', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#2A2A2A' }}>
            <Text style={{ color: '#A0A0A0', fontSize: 14, marginBottom: 8 }}>
              Current Price
            </Text>
            <View style={{ flexDirection: 'row', alignItems: 'baseline', marginBottom: 8 }}>
              <Text style={{ color: '#FFFFFF', fontSize: 32, fontWeight: 'bold' }}>
                ${selectedCrypto.price.toFixed(2)}
              </Text>
              <Text style={{ color: changeColor, fontSize: 18, fontWeight: '600', marginLeft: 12 }}>
                {formatChange(selectedCrypto.change24h)}
              </Text>
            </View>
            <Text style={{ color: '#A0A0A0', fontSize: 12 }}>
              24h change
            </Text>
          </View>
        </View>

        {/* Chart */}
        {chartLoading ? (
          <View style={{ paddingHorizontal: 24, marginBottom: 24, alignItems: 'center', paddingVertical: 20 }}>
            <ActivityIndicator size="large" color="#00D4FF" />
            <Text style={{ color: '#A0A0A0', marginTop: 12, fontSize: 14 }}>
              Loading chart...
            </Text>
          </View>
        ) : chartData ? (
          <View style={{ paddingHorizontal: 24, marginBottom: 24, backgroundColor: '#1A1A1A', borderRadius: 12, padding: 12, borderWidth: 1, borderColor: '#2A2A2A' }}>
            <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '600', marginBottom: 12 }}>
              7-Day Price Chart
            </Text>
            <LineChart
              data={chartData}
              width={screenWidth - 72}
              height={220}
              chartConfig={{
                backgroundColor: '#1A1A1A',
                backgroundGradientFrom: '#1A1A1A',
                backgroundGradientTo: '#1A1A1A',
                decimalPlaces: 2,
                color: (opacity = 1) => `rgba(160, 160, 160, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(160, 160, 160, ${opacity})`,
                style: {
                  borderRadius: 8
                },
                propsForDots: {
                  r: '4',
                  strokeWidth: '2',
                  stroke: '#00D4FF'
                }
              }}
              bezier
              style={{
                borderRadius: 8
              }}
            />
          </View>
        ) : null}

        {/* Statistics */}
        <View style={{ paddingHorizontal: 24, marginBottom: 24 }}>
          <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: 'bold', marginBottom: 12 }}>
            Market Statistics
          </Text>

          {/* High/Low */}
          <View style={{ flexDirection: 'row', marginBottom: 12, gap: 12 }}>
            <View style={{ flex: 1, backgroundColor: '#1A1A1A', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#2A2A2A' }}>
              <Text style={{ color: '#A0A0A0', fontSize: 12, marginBottom: 8 }}>
                24h High
              </Text>
              <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '600' }}>
                ${selectedCrypto.high24h.toFixed(2)}
              </Text>
            </View>
            <View style={{ flex: 1, backgroundColor: '#1A1A1A', borderRadius: 12, padding: 16, borderWidth: 1, borderColor: '#2A2A2A' }}>
              <Text style={{ color: '#A0A0A0', fontSize: 12, marginBottom: 8 }}>
                24h Low
              </Text>
              <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '600' }}>
                ${selectedCrypto.low24h.toFixed(2)}
              </Text>
            </View>
          </View>

          {/* Volume */}
          <View style={{ backgroundColor: '#1A1A1A', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#2A2A2A' }}>
            <Text style={{ color: '#A0A0A0', fontSize: 12, marginBottom: 8 }}>
              24h Volume
            </Text>
            <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '600' }}>
              ${(selectedCrypto.volume24h / 1000000).toFixed(2)}M
            </Text>
          </View>

          {/* Market Cap */}
          <View style={{ backgroundColor: '#1A1A1A', borderRadius: 12, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: '#2A2A2A' }}>
            <Text style={{ color: '#A0A0A0', fontSize: 12, marginBottom: 8 }}>
              Market Cap
            </Text>
            <Text style={{ color: '#FFFFFF', fontSize: 18, fontWeight: '600' }}>
              ${(selectedCrypto.marketCap / 1000000000).toFixed(2)}B
            </Text>
          </View>
        </View>

        {/* Data Source */}
        <View style={{ paddingHorizontal: 24, marginBottom: 24, backgroundColor: '#1A1A1A', borderRadius: 12, padding: 12, borderWidth: 1, borderColor: '#2A2A2A' }}>
          <Text style={{ color: '#A0A0A0', fontSize: 12, textAlign: 'center' }}>
            Official data: CoinGecko, {new Date(selectedCrypto.lastUpdated).toLocaleTimeString()}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
