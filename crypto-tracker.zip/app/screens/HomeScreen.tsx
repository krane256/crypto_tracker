import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert
} from 'react-native';
import { useCryptoStore } from '@/store/cryptoStore';
import { getTimeAgo, formatChange } from '@/services/cryptoAPI';
import { ScreenContainer } from '@/components/screen-container';

export default function HomeScreen({ navigation }: any) {
  const {
    prices,
    isLoading,
    isRefreshing,
    error,
    fetchPrices,
    refreshPrices,
    clearError
  } = useCryptoStore();

  const updateIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    // Initial fetch
    fetchPrices();

    // Set up auto-refresh every 10 seconds
    updateIntervalRef.current = setInterval(() => {
      refreshPrices();
    }, 10000);

    return () => {
      if (updateIntervalRef.current) {
        clearInterval(updateIntervalRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (error) {
      Alert.alert('Error', error, [{ text: 'OK', onPress: clearError }]);
    }
  }, [error]);

  const handleRefresh = async () => {
    await refreshPrices();
  };

  const handleCryptoPress = (cryptoId: string) => {
    navigation.navigate('Detail', { cryptoId });
  };

  const renderCryptoItem = ({ item }: any) => {
    const isPositive = item.change24h >= 0;
    const changeColor = isPositive ? '#00C853' : '#FF3B30';

    return (
      <TouchableOpacity
        onPress={() => handleCryptoPress(item.id)}
        style={{
          backgroundColor: '#1A1A1A',
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
          borderWidth: 1,
          borderColor: '#2A2A2A'
        }}
      >
        <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
          {/* Left side - Name and Symbol */}
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
              {item.name}
            </Text>
            <Text style={{ color: '#A0A0A0', fontSize: 14 }}>
              {item.symbol}
            </Text>
          </View>

          {/* Right side - Price and Change */}
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
              ${item.price.toFixed(2)}
            </Text>
            <Text style={{ color: changeColor, fontSize: 14, fontWeight: '500' }}>
              {formatChange(item.change24h)}
            </Text>
          </View>
        </View>

        {/* Data freshness indicator */}
        <View style={{ marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#2A2A2A' }}>
          <Text style={{ color: '#A0A0A0', fontSize: 12 }}>
            {getTimeAgo(item.lastUpdated)}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  const renderEmptyList = () => (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingVertical: 40 }}>
      <Text style={{ color: '#A0A0A0', fontSize: 16 }}>
        No cryptocurrencies available
      </Text>
    </View>
  );

  return (
    <ScreenContainer className="bg-[#0A0A0A]">
      {/* Header */}
      <View style={{ paddingHorizontal: 24, paddingVertical: 16, marginBottom: 8 }}>
        <Text style={{ color: '#FFFFFF', fontSize: 28, fontWeight: 'bold' }}>
          Crypto Tracker
        </Text>
        <Text style={{ color: '#A0A0A0', fontSize: 14, marginTop: 4 }}>
          Real-time prices
        </Text>
      </View>

      {/* Loading State */}
      {isLoading && prices.length === 0 ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <ActivityIndicator size="large" color="#00D4FF" />
          <Text style={{ color: '#A0A0A0', marginTop: 12, fontSize: 14 }}>
            Loading prices...
          </Text>
        </View>
      ) : (
        <FlatList
          data={prices}
          renderItem={renderCryptoItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24 }}
          ListEmptyComponent={renderEmptyList}
          refreshControl={
            <RefreshControl
              refreshing={isRefreshing}
              onRefresh={handleRefresh}
              tintColor="#00D4FF"
              colors={['#00D4FF']}
            />
          }
          scrollEnabled={true}
        />
      )}
    </ScreenContainer>
  );
}
