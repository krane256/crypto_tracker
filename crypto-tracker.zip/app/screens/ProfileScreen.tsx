import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Alert,
  ActivityIndicator
} from 'react-native';
import { useAuthStore } from '@/store/authStore';
import { ScreenContainer } from '@/components/screen-container';

export default function ProfileScreen() {
  const { user, logout, isLoading } = useAuthStore();

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to log out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
            } catch (error) {
              Alert.alert('Error', 'Failed to logout');
            }
          }
        }
      ]
    );
  };

  return (
    <ScreenContainer className="bg-[#0A0A0A]">
      <View className="flex-1 px-6 py-8">
        {/* Header */}
        <View className="mb-8">
          <Text className="text-3xl font-bold text-white">Profile</Text>
        </View>

        {/* User Info Card */}
        <View className="bg-[#1A1A1A] rounded-lg p-6 mb-8 border border-[#2A2A2A]">
          <View className="mb-6">
            <Text className="text-[#A0A0A0] text-sm mb-2">Username</Text>
            <Text className="text-white text-lg font-semibold">
              {user?.username || 'N/A'}
            </Text>
          </View>

          <View>
            <Text className="text-[#A0A0A0] text-sm mb-2">Email</Text>
            <Text className="text-white text-lg font-semibold">
              {user?.email || 'N/A'}
            </Text>
          </View>
        </View>

        {/* Logout Button */}
        <TouchableOpacity
          onPress={handleLogout}
          disabled={isLoading}
          style={{
            backgroundColor: '#FF3B30',
            paddingVertical: 14,
            borderRadius: 8,
            alignItems: 'center',
            opacity: isLoading ? 0.6 : 1
          }}
        >
          {isLoading ? (
            <ActivityIndicator color="#FFFFFF" size="small" />
          ) : (
            <Text className="text-white font-bold text-base">
              Logout
            </Text>
          )}
        </TouchableOpacity>

        {/* Info Section */}
        <View className="mt-8 bg-[#1A1A1A] rounded-lg p-4 border border-[#2A2A2A]">
          <Text className="text-white font-semibold mb-2">About Crypto Tracker</Text>
          <Text className="text-[#A0A0A0] text-sm leading-relaxed">
            Real-time cryptocurrency price tracking powered by CoinGecko API. Track your favorite cryptocurrencies and view detailed market data.
          </Text>
        </View>
      </View>
    </ScreenContainer>
  );
}
