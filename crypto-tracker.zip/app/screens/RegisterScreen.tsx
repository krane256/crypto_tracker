import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import { useAuthStore } from '@/store/authStore';
import { validateRegistration } from '@/services/authService';
import { ScreenContainer } from '@/components/screen-container';

export default function RegisterScreen({ navigation }: any) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  const { register, isLoading, error: authError } = useAuthStore();

  const handleRegister = async () => {
    // Validate inputs
    const validation = validateRegistration({
      username,
      email,
      password,
      confirmPassword
    });

    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});

    try {
      await register(username, email, password);
      Alert.alert(
        'Registration Successful',
        'Your account has been created. Please log in with your credentials.',
        [{ text: 'OK', onPress: () => navigation.navigate('Login') }]
      );
    } catch (error) {
      Alert.alert('Registration Failed', authError || 'Please try again');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={{ flex: 1 }}
    >
      <ScreenContainer className="bg-[#0A0A0A]">
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
        >
          <View className="flex-1 justify-center px-6 py-8">
            {/* Header */}
            <View className="mb-8 items-center">
              <Text className="text-4xl font-bold text-white mb-2">
                Create Account
              </Text>
              <Text className="text-base text-[#A0A0A0]">
                Join Crypto Tracker today
              </Text>
            </View>

            {/* Error Message */}
            {authError && (
              <View className="mb-4 bg-[#FF3B30] rounded-lg p-3">
                <Text className="text-white text-sm">{authError}</Text>
              </View>
            )}

            {/* Username Input */}
            <View className="mb-4">
              <Text className="text-white font-semibold mb-2">Username</Text>
              <TextInput
                style={{
                  backgroundColor: '#1A1A1A',
                  borderColor: errors.username ? '#FF3B30' : '#2A2A2A',
                  borderWidth: 1,
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 12,
                  color: '#FFFFFF',
                  fontSize: 16
                }}
                placeholder="Choose a username"
                placeholderTextColor="#A0A0A0"
                autoCapitalize="none"
                editable={!isLoading}
                value={username}
                onChangeText={setUsername}
              />
              {errors.username && (
                <Text className="text-[#FF3B30] text-sm mt-1">
                  {errors.username}
                </Text>
              )}
            </View>

            {/* Email Input */}
            <View className="mb-4">
              <Text className="text-white font-semibold mb-2">Email</Text>
              <TextInput
                style={{
                  backgroundColor: '#1A1A1A',
                  borderColor: errors.email ? '#FF3B30' : '#2A2A2A',
                  borderWidth: 1,
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 12,
                  color: '#FFFFFF',
                  fontSize: 16
                }}
                placeholder="Enter your email"
                placeholderTextColor="#A0A0A0"
                keyboardType="email-address"
                autoCapitalize="none"
                editable={!isLoading}
                value={email}
                onChangeText={setEmail}
              />
              {errors.email && (
                <Text className="text-[#FF3B30] text-sm mt-1">
                  {errors.email}
                </Text>
              )}
            </View>

            {/* Password Input */}
            <View className="mb-4">
              <Text className="text-white font-semibold mb-2">Password</Text>
              <TextInput
                style={{
                  backgroundColor: '#1A1A1A',
                  borderColor: errors.password ? '#FF3B30' : '#2A2A2A',
                  borderWidth: 1,
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 12,
                  color: '#FFFFFF',
                  fontSize: 16
                }}
                placeholder="Create a password"
                placeholderTextColor="#A0A0A0"
                secureTextEntry
                editable={!isLoading}
                value={password}
                onChangeText={setPassword}
              />
              {errors.password && (
                <Text className="text-[#FF3B30] text-sm mt-1">
                  {errors.password}
                </Text>
              )}
            </View>

            {/* Confirm Password Input */}
            <View className="mb-6">
              <Text className="text-white font-semibold mb-2">Confirm Password</Text>
              <TextInput
                style={{
                  backgroundColor: '#1A1A1A',
                  borderColor: errors.confirmPassword ? '#FF3B30' : '#2A2A2A',
                  borderWidth: 1,
                  borderRadius: 8,
                  paddingHorizontal: 12,
                  paddingVertical: 12,
                  color: '#FFFFFF',
                  fontSize: 16
                }}
                placeholder="Confirm your password"
                placeholderTextColor="#A0A0A0"
                secureTextEntry
                editable={!isLoading}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
              />
              {errors.confirmPassword && (
                <Text className="text-[#FF3B30] text-sm mt-1">
                  {errors.confirmPassword}
                </Text>
              )}
            </View>

            {/* Register Button */}
            <TouchableOpacity
              onPress={handleRegister}
              disabled={isLoading}
              style={{
                backgroundColor: '#00D4FF',
                paddingVertical: 14,
                borderRadius: 8,
                alignItems: 'center',
                opacity: isLoading ? 0.6 : 1
              }}
            >
              {isLoading ? (
                <ActivityIndicator color="#0A0A0A" size="small" />
              ) : (
                <Text className="text-[#0A0A0A] font-bold text-base">
                  Register
                </Text>
              )}
            </TouchableOpacity>

            {/* Login Link */}
            <View className="mt-6 flex-row justify-center items-center">
              <Text className="text-[#A0A0A0] text-sm">
                Already have an account?{' '}
              </Text>
              <TouchableOpacity
                onPress={() => navigation.navigate('Login')}
                disabled={isLoading}
              >
                <Text className="text-[#00D4FF] font-semibold text-sm">
                  Login
                </Text>
              </TouchableOpacity>
            </View>

            {/* Password Requirements */}
            <View className="mt-8 bg-[#1A1A1A] rounded-lg p-4 border border-[#2A2A2A]">
              <Text className="text-white font-semibold mb-2">Password Requirements:</Text>
              <Text className="text-[#A0A0A0] text-sm mb-1">
                • At least 6 characters
              </Text>
              <Text className="text-[#A0A0A0] text-sm mb-1">
                • At least one letter
              </Text>
              <Text className="text-[#A0A0A0] text-sm">
                • At least one number
              </Text>
            </View>
          </View>
        </ScrollView>
      </ScreenContainer>
    </KeyboardAvoidingView>
  );
}
