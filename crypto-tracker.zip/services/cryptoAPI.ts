import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const COINGECKO_API = 'https://api.coingecko.com/api/v3';
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Create axios instance with timeout
const apiClient = axios.create({
  baseURL: COINGECKO_API,
  timeout: 10000
});

export interface PriceData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  lastUpdated: number;
}

export interface MarketChartData {
  prices: Array<[number, number]>;
  market_caps: Array<[number, number]>;
  volumes: Array<[number, number]>;
}

export interface CryptoMarketData {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  marketCap: number;
  lastUpdated: number;
}

/**
 * Fetch current prices for multiple cryptocurrencies
 */
export const fetchCryptoPrices = async (
  cryptoIds: string[] = ['bitcoin', 'ethereum', 'solana', 'binancecoin', 'tether']
): Promise<PriceData[]> => {
  try {
    const response = await apiClient.get('/simple/price', {
      params: {
        ids: cryptoIds.join(','),
        vs_currencies: 'usd',
        include_24hr_change: true
      }
    });

    const cryptoSymbols: Record<string, string> = {
      bitcoin: 'BTC',
      ethereum: 'ETH',
      solana: 'SOL',
      binancecoin: 'BNB',
      tether: 'USDT'
    };

    const cryptoNames: Record<string, string> = {
      bitcoin: 'Bitcoin',
      ethereum: 'Ethereum',
      solana: 'Solana',
      binancecoin: 'Binance Coin',
      tether: 'Tether'
    };

    const now = Date.now();
    const prices: PriceData[] = cryptoIds.map(id => ({
      id,
      symbol: cryptoSymbols[id] || id.toUpperCase(),
      name: cryptoNames[id] || id,
      price: response.data[id]?.usd || 0,
      change24h: response.data[id]?.usd_24h_change || 0,
      lastUpdated: now
    }));

    // Cache the prices
    await cachePrices(prices, now);

    return prices;
  } catch (error) {
    console.error('Error fetching prices:', error);
    // Try to return cached prices
    const cached = await getCachedPrices();
    if (cached) {
      return cached;
    }
    throw error;
  }
};

/**
 * Fetch detailed market data for a specific cryptocurrency
 */
export const fetchCryptoMarketData = async (cryptoId: string): Promise<CryptoMarketData> => {
  try {
    const response = await apiClient.get(`/simple/price`, {
      params: {
        ids: cryptoId,
        vs_currencies: 'usd',
        include_market_cap: true,
        include_24hr_vol: true,
        include_24hr_change: true,
        include_high_low_24h: true
      }
    });

    const cryptoSymbols: Record<string, string> = {
      bitcoin: 'BTC',
      ethereum: 'ETH',
      solana: 'SOL',
      binancecoin: 'BNB',
      tether: 'USDT'
    };

    const cryptoNames: Record<string, string> = {
      bitcoin: 'Bitcoin',
      ethereum: 'Ethereum',
      solana: 'Solana',
      binancecoin: 'Binance Coin',
      tether: 'Tether'
    };

    const data = response.data[cryptoId];
    const now = Date.now();

    const marketData: CryptoMarketData = {
      id: cryptoId,
      symbol: cryptoSymbols[cryptoId] || cryptoId.toUpperCase(),
      name: cryptoNames[cryptoId] || cryptoId,
      price: data?.usd || 0,
      change24h: data?.usd_24h_change || 0,
      high24h: data?.usd_24h_high || 0,
      low24h: data?.usd_24h_low || 0,
      volume24h: data?.usd_24h_vol || 0,
      marketCap: data?.usd_market_cap || 0,
      lastUpdated: now
    };

    return marketData;
  } catch (error) {
    console.error('Error fetching market data:', error);
    throw error;
  }
};

/**
 * Fetch 7-day price chart data
 */
export const fetchChartData = async (cryptoId: string, days: number = 7): Promise<MarketChartData> => {
  try {
    const response = await apiClient.get(`/coins/${cryptoId}/market_chart`, {
      params: {
        vs_currency: 'usd',
        days: days
      }
    });

    return response.data;
  } catch (error) {
    console.error('Error fetching chart data:', error);
    // Try to return cached chart data
    const cached = await getCachedChartData(cryptoId);
    if (cached) {
      return cached;
    }
    throw error;
  }
};

/**
 * Cache prices to AsyncStorage
 */
const cachePrices = async (prices: PriceData[], timestamp: number): Promise<void> => {
  try {
    await AsyncStorage.setItem('cachedPrices', JSON.stringify({
      prices,
      timestamp
    }));
  } catch (error) {
    console.error('Error caching prices:', error);
  }
};

/**
 * Get cached prices from AsyncStorage
 */
const getCachedPrices = async (): Promise<PriceData[] | null> => {
  try {
    const cached = await AsyncStorage.getItem('cachedPrices');
    if (cached) {
      const { prices, timestamp } = JSON.parse(cached);
      const now = Date.now();
      
      // Return cache if still valid
      if (now - timestamp < CACHE_DURATION) {
        return prices;
      }
    }
    return null;
  } catch (error) {
    console.error('Error retrieving cached prices:', error);
    return null;
  }
};

/**
 * Cache chart data to AsyncStorage
 */
const cacheChartData = async (cryptoId: string, data: MarketChartData, timestamp: number): Promise<void> => {
  try {
    await AsyncStorage.setItem(`cachedChart_${cryptoId}`, JSON.stringify({
      data,
      timestamp
    }));
  } catch (error) {
    console.error('Error caching chart data:', error);
  }
};

/**
 * Get cached chart data from AsyncStorage
 */
const getCachedChartData = async (cryptoId: string): Promise<MarketChartData | null> => {
  try {
    const cached = await AsyncStorage.getItem(`cachedChart_${cryptoId}`);
    if (cached) {
      const { data, timestamp } = JSON.parse(cached);
      const now = Date.now();
      
      // Return cache if still valid
      if (now - timestamp < CACHE_DURATION) {
        return data;
      }
    }
    return null;
  } catch (error) {
    console.error('Error retrieving cached chart data:', error);
    return null;
  }
};

/**
 * Format price for display
 */
export const formatPrice = (price: number): string => {
  if (price >= 1000) {
    return `$${(price / 1000).toFixed(2)}K`;
  }
  return `$${price.toFixed(2)}`;
};

/**
 * Format change percentage
 */
export const formatChange = (change: number): string => {
  const sign = change >= 0 ? '+' : '';
  return `${sign}${change.toFixed(2)}%`;
};

/**
 * Get time ago string
 */
export const getTimeAgo = (timestamp: number): string => {
  const now = Date.now();
  const diff = now - timestamp;
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  
  if (seconds < 30) return 'Live';
  if (seconds < 60) return `${seconds}s ago`;
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  
  return 'Outdated';
};
