import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface User {
  id: string;
  username: string;
  email: string;
}

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  restoreToken: () => Promise<void>;
  clearError: () => void;
}

// Mock user database (in production, this would be on the server)
const mockUsers: Record<string, { id: string; username: string; email: string; password: string }> = {
  'user1@example.com': {
    id: '1',
    username: 'user1',
    email: 'user1@example.com',
    password: 'password123'
  }
};

// Simple JWT-like token generator (mock)
const generateToken = (userId: string): string => {
  const timestamp = Date.now();
  return `mock_jwt_${userId}_${timestamp}`;
};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isLoading: false,
  error: null,

  login: async (email: string, password: string) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));

      // Mock authentication
      const user = mockUsers[email];
      if (!user || user.password !== password) {
        throw new Error('Invalid email or password');
      }

      const token = generateToken(user.id);
      
      // Save token to AsyncStorage
      await AsyncStorage.setItem('authToken', token);
      await AsyncStorage.setItem('user', JSON.stringify({
        id: user.id,
        username: user.username,
        email: user.email
      }));

      set({
        user: {
          id: user.id,
          username: user.username,
          email: user.email
        },
        token,
        isLoading: false
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Login failed';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  register: async (username: string, email: string, password: string) => {
    set({ isLoading: true, error: null });
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 500));

      // Check if user already exists
      if (mockUsers[email]) {
        throw new Error('Email already registered');
      }

      // Create new user
      const userId = String(Object.keys(mockUsers).length + 1);
      mockUsers[email] = {
        id: userId,
        username,
        email,
        password
      };

      set({
        isLoading: false,
        error: null
      });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Registration failed';
      set({ error: errorMessage, isLoading: false });
      throw error;
    }
  },

  logout: async () => {
    try {
      await AsyncStorage.removeItem('authToken');
      await AsyncStorage.removeItem('user');
      set({ user: null, token: null, error: null });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Logout failed';
      set({ error: errorMessage });
      throw error;
    }
  },

  restoreToken: async () => {
    set({ isLoading: true });
    try {
      const token = await AsyncStorage.getItem('authToken');
      const userJson = await AsyncStorage.getItem('user');

      if (token && userJson) {
        const user = JSON.parse(userJson);
        set({ token, user, isLoading: false });
      } else {
        set({ isLoading: false });
      }
    } catch (error) {
      set({ isLoading: false });
    }
  },

  clearError: () => set({ error: null })
}));
