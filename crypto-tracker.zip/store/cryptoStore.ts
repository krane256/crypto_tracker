import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface CryptoPrice {
  id: string;
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  lastUpdated: number;
}

export interface CryptoDetail extends CryptoPrice {
  high24h: number;
  low24h: number;
  volume24h: number;
  marketCap: number;
  chartData: Array<{ timestamp: number; price: number }>;
}

interface CryptoState {
  prices: CryptoPrice[];
  selectedCrypto: CryptoDetail | null;
  isLoading: boolean;
  isRefreshing: boolean;
  error: string | null;
  lastFetchTime: number;

  // Actions
  fetchPrices: () => Promise<void>;
  fetchCryptoDetail: (cryptoId: string) => Promise<void>;
  refreshPrices: () => Promise<void>;
  clearError: () => void;
  setCryptoDetail: (crypto: CryptoDetail) => void;
}

const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes
const COINGECKO_API = 'https://api.coingecko.com/api/v3';

const cryptoIds = ['bitcoin', 'ethereum', 'solana', 'binancecoin', 'tether'];
const cryptoSymbols: Record<string, string> = {
  bitcoin: 'BTC',
  ethereum: 'ETH',
  solana: 'SOL',
  binancecoin: 'BNB',
  tether: 'USDT'
};

const cryptoNames: Record<string, string> = {
  bitcoin: 'Bitcoin',
  ethereum: 'Ethereum',
  solana: 'Solana',
  binancecoin: 'Binance Coin',
  tether: 'Tether'
};

export const useCryptoStore = create<CryptoState>((set, get) => ({
  prices: [],
  selectedCrypto: null,
  isLoading: false,
  isRefreshing: false,
  error: null,
  lastFetchTime: 0,

  fetchPrices: async () => {
    const state = get();
    const now = Date.now();

    // Check cache validity
    if (state.prices.length > 0 && now - state.lastFetchTime < CACHE_DURATION) {
      return;
    }

    set({ isLoading: true, error: null });
    try {
      const response = await fetch(
        `${COINGECKO_API}/simple/price?ids=${cryptoIds.join(',')}&vs_currencies=usd&include_24hr_change=true`
      );

      if (!response.ok) throw new Error('Failed to fetch prices');

      const data = await response.json();

      const prices: CryptoPrice[] = cryptoIds.map(id => ({
        id,
        symbol: cryptoSymbols[id],
        name: cryptoNames[id],
        price: data[id]?.usd || 0,
        change24h: data[id]?.usd_24h_change || 0,
        lastUpdated: now
      }));

      // Cache prices to AsyncStorage
      await AsyncStorage.setItem('cachedPrices', JSON.stringify({
        prices,
        timestamp: now
      }));

      set({ prices, isLoading: false, lastFetchTime: now });
    } catch (error) {
      // Try to load from cache on error
      try {
        const cached = await AsyncStorage.getItem('cachedPrices');
        if (cached) {
          const { prices } = JSON.parse(cached);
          set({ prices, isLoading: false });
          return;
        }
      } catch (cacheError) {
        // Ignore cache errors
      }

      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch prices';
      set({ error: errorMessage, isLoading: false });
    }
  },

  fetchCryptoDetail: async (cryptoId: string) => {
    set({ isLoading: true, error: null });
    try {
      // Fetch current price and market data
      const priceResponse = await fetch(
        `${COINGECKO_API}/simple/price?ids=${cryptoId}&vs_currencies=usd&include_market_cap=true&include_24hr_vol=true&include_24hr_change=true&include_high_low_24h=true`
      );

      if (!priceResponse.ok) throw new Error('Failed to fetch price data');

      const priceData = await priceResponse.json();
      const cryptoData = priceData[cryptoId];

      // Fetch 7-day chart data
      const chartResponse = await fetch(
        `${COINGECKO_API}/coins/${cryptoId}/market_chart?vs_currency=usd&days=7`
      );

      if (!chartResponse.ok) throw new Error('Failed to fetch chart data');

      const chartData = await chartResponse.json();

      const now = Date.now();
      const detail: CryptoDetail = {
        id: cryptoId,
        symbol: cryptoSymbols[cryptoId],
        name: cryptoNames[cryptoId],
        price: cryptoData.usd || 0,
        change24h: cryptoData.usd_24h_change || 0,
        high24h: cryptoData.usd_24h_high || 0,
        low24h: cryptoData.usd_24h_low || 0,
        volume24h: cryptoData.usd_24h_vol || 0,
        marketCap: cryptoData.usd_market_cap || 0,
        lastUpdated: now,
        chartData: (chartData.prices || []).map((price: [number, number]) => ({
          timestamp: price[0],
          price: price[1]
        }))
      };

      // Cache detail to AsyncStorage
      await AsyncStorage.setItem(`cryptoDetail_${cryptoId}`, JSON.stringify(detail));

      set({ selectedCrypto: detail, isLoading: false });
    } catch (error) {
      // Try to load from cache on error
      try {
        const cached = await AsyncStorage.getItem(`cryptoDetail_${cryptoId}`);
        if (cached) {
          const detail = JSON.parse(cached);
          set({ selectedCrypto: detail, isLoading: false });
          return;
        }
      } catch (cacheError) {
        // Ignore cache errors
      }

      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch crypto details';
      set({ error: errorMessage, isLoading: false });
    }
  },

  refreshPrices: async () => {
    set({ isRefreshing: true, error: null });
    try {
      const response = await fetch(
        `${COINGECKO_API}/simple/price?ids=${cryptoIds.join(',')}&vs_currencies=usd&include_24hr_change=true`
      );

      if (!response.ok) throw new Error('Failed to fetch prices');

      const data = await response.json();
      const now = Date.now();

      const prices: CryptoPrice[] = cryptoIds.map(id => ({
        id,
        symbol: cryptoSymbols[id],
        name: cryptoNames[id],
        price: data[id]?.usd || 0,
        change24h: data[id]?.usd_24h_change || 0,
        lastUpdated: now
      }));

      // Cache prices to AsyncStorage
      await AsyncStorage.setItem('cachedPrices', JSON.stringify({
        prices,
        timestamp: now
      }));

      set({ prices, isRefreshing: false, lastFetchTime: now });
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to refresh prices';
      set({ error: errorMessage, isRefreshing: false });
    }
  },

  clearError: () => set({ error: null }),

  setCryptoDetail: (crypto: CryptoDetail) => set({ selectedCrypto: crypto })
}));
